﻿namespace RecipeApp
{
    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }
        public double ScalingFactor { get; internal set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public double GetTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories);
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }

    class Program
    {
        static List<Recipe> recipes;

        static void Main(string[] args)
        {
            recipes = new List<Recipe>();

            while (true)
            {
                Console.WriteLine("Welcome to RecipeApp!");
                Console.WriteLine("1. Enter Recipe Details");
                Console.WriteLine("2. Display Recipe List");
                Console.WriteLine("3. Display Recipe");
                Console.WriteLine("4. Scale Recipe");
                Console.WriteLine("5. Reset Scaling");
                Console.WriteLine("6. Clear Recipe");
                Console.WriteLine("7. Exit");
                Console.WriteLine("Enter your choice (1-7):");

                string choice = Console.ReadLine();
                Console.WriteLine();

                switch (choice)
                {
                    case "1":
                        EnterRecipeDetails();
                        break;
                    case "2":
                        DisplayRecipeList();
                        break;
                    case "3":
                        DisplayRecipe();
                        break;
                    case "4":
                        ScaleRecipe();
                        break;
                    case "5":
                        ResetScaling();
                        break;
                    case "6":
                        ClearRecipe();
                        break;
                    case "7":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine();
            }
        }

        static void EnterRecipeDetails()
        {
            Console.WriteLine("Enter the recipe name:");
            string name = Console.ReadLine();

            Recipe recipe = new Recipe(name);

            Console.WriteLine("Enter the number of ingredients:");
            int numIngredients = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the details for each ingredient:");
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("Ingredient {0}:", i + 1);
                Console.WriteLine("Name:");
                string ingredientName = Console.ReadLine();

                Console.WriteLine("Quantity:");
                double quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Unit of Measurement:");
                string unit = Console.ReadLine();

                Console.WriteLine("Calories:");
                double calories = double.Parse(Console.ReadLine());

                Console.WriteLine("Food Group:");
                string foodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                recipe.Ingredients.Add(ingredient);

                Console.WriteLine();
            }

            Console.WriteLine("Enter the number of steps:");
            int numSteps = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the description for each step:");
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine("Step {0}:", i + 1);
                string step = Console.ReadLine();
                recipe.Steps.Add(step);
            }

            recipes.Add(recipe);
        }

        static void DisplayRecipeList()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Recipe List (Alphabetical Order):");
            List<string> recipeNames = recipes.OrderBy(recipe => recipe.Name).Select(recipe => recipe.Name).ToList();
            foreach (string recipeName in recipeNames)
            {
                Console.WriteLine("- " + recipeName);
            }
        }

        static void DisplayRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Enter the recipe name:");
            string name = Console.ReadLine();

            Recipe recipe = recipes.Find(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            Console.WriteLine("Recipe Details:");
            Console.WriteLine("Name: " + recipe.Name);

            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                double scaledQuantity = ingredient.Quantity * recipe.ScalingFactor;
                Console.WriteLine("- {0} {1} of {2} ({3} calories) - {4}", scaledQuantity, ingredient.Unit, ingredient.Name, ingredient.Calories, ingredient.FoodGroup);
            }

            Console.WriteLine("Total Calories: " + recipe.GetTotalCalories());

            Console.WriteLine("Steps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, recipe.Steps[i]);
            }
        }

        static void ScaleRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Enter the recipe name:");
            string name = Console.ReadLine();

            Recipe recipe = recipes.Find(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            Console.WriteLine("Enter the scaling factor (0.5, 2, 3):");
            double scalingFactor = double.Parse(Console.ReadLine());
            recipe.ScalingFactor = scalingFactor;

            Console.WriteLine("Recipe scaled successfully.");
        }

        static void ResetScaling()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Enter the recipe name:");
            string name = Console.ReadLine();

            Recipe recipe = recipes.Find(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            recipe.ScalingFactor = 1.0;
            Console.WriteLine("Scaling reset to original values.");
        }

        static void ClearRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("Enter the recipe name:");
            string name = Console.ReadLine();

            Recipe recipe = recipes.Find(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            recipes.Remove(recipe);
            Console.WriteLine("Recipe removed successfully.");
        }
    }
}