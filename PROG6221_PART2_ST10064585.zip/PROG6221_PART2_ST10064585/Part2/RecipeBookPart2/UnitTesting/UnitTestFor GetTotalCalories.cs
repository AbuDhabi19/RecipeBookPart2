﻿using NUnit.Framework;
using RecipeApp;

namespace RecipeApp.Tests
{
    [TestFixture]
    public class RecipeTests
    {
        [Test]
        public void GetTotalCalories_RecipeWithIngredients_CalculatesTotalCalories()
        {
            // Arrange
            Recipe recipe = new Recipe("Test Recipe");
            recipe.Ingredients.Add(new Ingredient("Ingredient 1", 2, "oz", 100, "Food Group 1"));
            recipe.Ingredients.Add(new Ingredient("Ingredient 2", 3, "tbsp", 50, "Food Group 2"));
            recipe.Ingredients.Add(new Ingredient("Ingredient 3", 1, "cup", 200, "Food Group 1"));

            double expectedTotalCalories = 2 * 100 + 3 * 50 + 1 * 200;

            // Act
            double actualTotalCalories = recipe.GetTotalCalories();

            // Assert
            Assert.AreEqual(expectedTotalCalories, actualTotalCalories);
        }
    }
}
